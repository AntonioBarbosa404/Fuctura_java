package model;

public class TipoVeiculo {
    private String categoria;
    private String descricao;

    // Construtores, getters e setters
}
